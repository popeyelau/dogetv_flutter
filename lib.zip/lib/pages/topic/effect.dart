import 'package:dogetv_flutter/pages/category/action.dart';
import 'package:dogetv_flutter/pages/topic/action.dart';
import 'package:dogetv_flutter/pages/topic/state.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/repository/movie.dart';

Effect<TopicsPageState> buildEffect() {
  return combineEffects(<Object, Effect<TopicsPageState>>{
    Lifecycle.initState: _init,
    CateogryPageAction.onFetch: _onFetch
  });
}

void _init(Action action, Context<TopicsPageState> ctx) async {
  APIs.getTopics().then((topics) {
    ctx.dispatch(TopicsPageActionCreator.didLoadAction(topics));
  });
}

void _onFetch(Action action, Context<TopicsPageState> ctx) async {
  APIs.getTopics().then((topics) {
    ctx.dispatch(TopicsPageActionCreator.didLoadAction(topics));
  });
}

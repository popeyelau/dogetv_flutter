import 'dart:ui';

import 'package:dogetv_flutter/models/home.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:flutter/material.dart';

class TopicItemComponent extends Component<Topic> {
  TopicItemComponent() : super(view: buildView);
}

Widget buildView(Topic topic, dispatch, ViewService viewService) {
  return Container(
    margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(6.0),
      image: DecorationImage(
        fit: BoxFit.cover,
        image: NetworkImage(
          "http://v.popeye.vip" + topic.cover,
        ),
      ),
    ),
    child: Stack(
      children: <Widget>[
        new Center(
            child: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
            child: Container(
              padding: EdgeInsets.all(8),
              decoration:
                  BoxDecoration(color: Colors.grey.shade500.withOpacity(0.5)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "#" + topic.title + "#",
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(height: 8.0),
                  Text(topic.desc),
                ],
              ),
            ),
          ),
        )),
      ],
    ),
  );
}

import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/models/video.dart';
import 'package:dogetv_flutter/models/home.dart';

class HomePageState implements Cloneable<HomePageState> {
  Home home = Home();

  @override
  HomePageState clone() {
    return HomePageState()..home = home;
  }
}

HomePageState initState(Map<String, dynamic> map) {
  return HomePageState();
}

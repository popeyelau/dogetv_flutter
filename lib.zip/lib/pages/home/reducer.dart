import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/models/home.dart';
import 'main.dart';

Reducer<HomePageState> buildReducer() {
  return asReducer(<Object, Reducer<HomePageState>>{
    HomePageAction.didLoad: loadMovies,
  });
}

HomePageState loadMovies(HomePageState state, Action action) {
  HomePageState newState = state.clone();
  Home home = action.payload;
  newState.home = home;
  return newState;
}

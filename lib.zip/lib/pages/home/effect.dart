import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/pages/home/action.dart';
import 'package:dogetv_flutter/pages/home/state.dart';
import 'package:dogetv_flutter/repository/movie.dart';
import 'package:dogetv_flutter/utils/api_client.dart';

Effect<HomePageState> buildEffect() {
  return combineEffects(
      <Object, Effect<HomePageState>>{Lifecycle.initState: _init});
}

void _init(Action action, Context<HomePageState> ctx) async {
  APIs.getMovies().then((movies) {
    ctx.dispatch(HomePageActionCreator.didLoadAction(movies));
  });
}

import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/models/home.dart';

enum HomePageAction {
  onLoad,
  didLoad,
}

class HomePageActionCreator {
  static Action onLoadAction(bool isLoading) {
    return Action(HomePageAction.onLoad, payload: isLoading);
  }

  static Action didLoadAction(Home home) {
    return Action(HomePageAction.didLoad, payload: home);
  }
}

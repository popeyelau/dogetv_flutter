import 'package:dogetv_flutter/pages/topic/page.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:flutter/material.dart';

class SectionHeaderComponent extends Component<String> {
  SectionHeaderComponent()
      : super(
          view: buildView,
          effect: buildEffect(),
        );
}

Widget buildView(String state, dispatch, ViewService viewService) {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
    child: Row(
      children: <Widget>[
        Icon(Icons.vertical_align_top),
        Expanded(
          child: Text(
            state,
            textAlign: TextAlign.left,
          ),
        ),
        IconButton(
          icon: Icon(
            Icons.keyboard_arrow_right,
          ),
          onPressed: () {
            dispatch(SectionHeaderActionCreator.onShowMore());
          },
        )
      ],
    ),
  );
}

enum SectionHeaderAction { onShowMore }

class SectionHeaderActionCreator {
  static Action onShowMore() {
    return Action(SectionHeaderAction.onShowMore);
  }
}

Effect buildEffect() {
  return combineEffects(<Object, Effect>{
    SectionHeaderAction.onShowMore: onShowMore,
  });
}

onShowMore(Action action, Context ctx) {
  Navigator.of(ctx.context).push(MaterialPageRoute(builder: (context) {
    return TopicsPage().buildPage(null);
  }));
}

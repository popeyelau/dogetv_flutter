import 'package:dogetv_flutter/models/home.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:flutter/material.dart';

class TopicHorizontalComponent extends Component<List<Topic>> {
  TopicHorizontalComponent() : super(view: buildView);
}

Widget buildView(List<Topic> state, dispatch, ViewService viewService) {
  return Container(
    height: 150,
    padding: EdgeInsets.symmetric(vertical: 8.0),
    child: ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: state.length,
      itemBuilder: (BuildContext context, int index) {
        final video = state[index];
        return Container(
          width: 100,
          margin: EdgeInsets.symmetric(horizontal: 8.0),
          child: Column(
            children: <Widget>[
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 2,
                        offset: Offset(1, 1),
                        spreadRadius: 3,
                        color: Colors.black12)
                  ],
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(
                      "http://v.popeye.vip" + video.cover,
                    ),
                  ),
                  borderRadius: BorderRadius.circular(50),
                ),
              ),
              SizedBox(height: 8.0),
              Expanded(
                child: Text(
                  video.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
}

import 'package:dogetv_flutter/models/video.dart';
import 'package:dogetv_flutter/pages/category/action.dart';
import 'package:dogetv_flutter/pages/category/state.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/repository/movie.dart';

Effect<CategoryPageState> buildEffect() {
  return combineEffects(<Object, Effect<CategoryPageState>>{
    Lifecycle.initState: _init,
    CateogryPageAction.onFetch: _onFetch
  });
}

void _init(Action action, Context<CategoryPageState> ctx) async {
  APIs.getVideos(Category.film).then((videos) {
    ctx.dispatch(CategoryPageActionCreator.didLoadAction(videos));
  });
}

void _onFetch(Action action, Context<CategoryPageState> ctx) async {
  Category category = action.payload;
  APIs.getVideos(category).then((videos) {
    ctx.dispatch(CategoryPageActionCreator.didLoadAction(videos));
  });
}

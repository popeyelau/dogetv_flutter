import 'package:dogetv_flutter/pages/category/component/video_item.dart';
import 'package:dogetv_flutter/pages/category/state.dart';
import 'package:fish_redux/fish_redux.dart';

class CategoryVideoListAdapter extends DynamicFlowAdapter<CategoryPageState> {
  CategoryVideoListAdapter()
      : super(
          pool: <String, Component<Object>>{
            "video": VideoGridItemComponent(),
          },
          connector: CategoryVideoListConnector(),
        );
}

class CategoryVideoListConnector
    extends ConnOp<CategoryPageState, List<ItemBean>> {
  @override
  List<ItemBean> get(CategoryPageState state) {
    return state.videos.map((video) => ItemBean("video", video)).toList();
  }

  @override
  void set(CategoryPageState state, List<ItemBean> subState) {}
}

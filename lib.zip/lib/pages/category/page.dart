import 'package:dogetv_flutter/models/video.dart';
import 'package:dogetv_flutter/pages/category/action.dart';
import 'package:dogetv_flutter/pages/category/adapter.dart';
import 'package:dogetv_flutter/pages/category/effect.dart';
import 'package:dogetv_flutter/pages/category/reducer.dart';
import 'package:dogetv_flutter/pages/category/state.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:flutter/material.dart';

class CategoryPage extends Page<CategoryPageState, Map<String, dynamic>> {
  CategoryPage()
      : super(
          view: buildView,
          effect: buildEffect(),
          initState: initState,
          reducer: buildReducer(),
          dependencies: Dependencies<CategoryPageState>(
              adapter: CategoryVideoListAdapter(),
              slots: <String, Dependent<CategoryPageState>>{}),
        );
}

Widget buildView(
    CategoryPageState state, dynamic dispatch, ViewService viewService) {
  final ListAdapter listAdapter = viewService.buildAdapter();
  List<Tab> tabs =
      ["电影", "电视剧", "综艺", "动漫", "记录片"].map((item) => Tab(text: item)).toList();

  return DefaultTabController(
    length: tabs.length,
    child: Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("影视库"),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.data_usage),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.view_list),
            onPressed: () {},
          ),
        ],
        bottom: TabBar(
          onTap: (index) {
            dispatch(CategoryPageActionCreator.onFetchAction(
                Category.values[index]));
          },
          indicatorSize: TabBarIndicatorSize.label,
          isScrollable: false,
          tabs: tabs,
        ),
      ),
      body: TabBarView(
        children: <Widget>[
          CustomScrollView(
            slivers: <Widget>[
              SliverGrid(
                delegate: SliverChildBuilderDelegate(listAdapter.itemBuilder,
                    childCount: listAdapter.itemCount),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 9 / 14,
                    mainAxisSpacing: 8.0,
                    crossAxisSpacing: 0.0),
              )
            ],
          ),
          CustomScrollView(
            slivers: <Widget>[
              SliverGrid(
                delegate: SliverChildBuilderDelegate(listAdapter.itemBuilder,
                    childCount: listAdapter.itemCount),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 9 / 14,
                    mainAxisSpacing: 8.0,
                    crossAxisSpacing: 0.0),
              )
            ],
          ),
          CustomScrollView(
            slivers: <Widget>[
              SliverGrid(
                delegate: SliverChildBuilderDelegate(listAdapter.itemBuilder,
                    childCount: listAdapter.itemCount),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 9 / 14,
                    mainAxisSpacing: 8.0,
                    crossAxisSpacing: 0.0),
              )
            ],
          ),
          CustomScrollView(
            slivers: <Widget>[
              SliverGrid(
                delegate: SliverChildBuilderDelegate(listAdapter.itemBuilder,
                    childCount: listAdapter.itemCount),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 9 / 14,
                    mainAxisSpacing: 8.0,
                    crossAxisSpacing: 0.0),
              )
            ],
          ),
          CustomScrollView(
            slivers: <Widget>[
              SliverGrid(
                delegate: SliverChildBuilderDelegate(listAdapter.itemBuilder,
                    childCount: listAdapter.itemCount),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 9 / 14,
                    mainAxisSpacing: 8.0,
                    crossAxisSpacing: 0.0),
              )
            ],
          ),
        ],
      ),
    ),
  );
}

import 'package:fish_redux/fish_redux.dart';
import 'package:dogetv_flutter/models/video.dart';

class CategoryPageState implements Cloneable<CategoryPageState> {
  List<Video> videos = [];

  @override
  CategoryPageState clone() {
    return CategoryPageState()..videos = videos;
  }
}

CategoryPageState initState(Map<String, dynamic> map) {
  return CategoryPageState();
}

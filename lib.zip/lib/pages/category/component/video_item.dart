import 'package:dogetv_flutter/models/video.dart';
import 'package:fish_redux/fish_redux.dart';
import 'package:flutter/material.dart';

class VideoGridItemComponent extends Component<Video> {
  VideoGridItemComponent() : super(view: buildView);
}

Widget buildView(Video video, dispatch, ViewService viewService) {
  return Container(
    child: Column(children: <Widget>[
      Expanded(
        child: Card(
          margin: EdgeInsets.all(2),
          elevation: 5.0,
          child: Image(
            fit: BoxFit.cover,
            image: NetworkImage(
              "http://v.popeye.vip" + video.cover,
            ),
          ),
        ),
      ),
      Text(
        video.name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    ]),
  );
}

import 'package:dogetv_flutter/models/video.dart';
import 'package:fish_redux/fish_redux.dart';
import 'main.dart';

Reducer<CategoryPageState> buildReducer() {
  return asReducer(<Object, Reducer<CategoryPageState>>{
    CateogryPageAction.didLoad: loadVideos,
  });
}

CategoryPageState loadVideos(CategoryPageState state, Action action) {
  CategoryPageState newState = state.clone();
  List<Video> videos = action.payload;
  newState.videos = videos;
  return newState;
}

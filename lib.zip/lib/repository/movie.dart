import 'package:dogetv_flutter/models/video.dart';
import 'package:dogetv_flutter/models/home.dart';
import 'package:dogetv_flutter/utils/api_client.dart';

class APIs {
  static Future<Home> getMovies() async {
    Map sections = await APIClient().get("https://tv.popeye.vip/videos");
    Map topics = await APIClient().get("https://tv.popeye.vip/topics");

    Home home = Home();

    for (var section in sections["data"]) {
      home.sections.add(VideoSection.fromJson(section));
    }
    for (var section in topics["data"]) {
      home.topics.add(Topic.fromJson(section));
    }

    return home;
  }

  static Future<List<Video>> getVideos(Category category) async {
    String key = category.toString().replaceAll("Category.", "");
    Map map = await APIClient().get("https://tv.popeye.vip/videos/$key");
    List<Video> videos = [];
    for (var video in map["data"]["items"]) {
      videos.add(Video.fromJson(video));
    }
    return videos;
  }

  static Future<List<Topic>> getTopics() async {
    Map map = await APIClient().get("https://tv.popeye.vip/topics");
    List<Topic> topics = [];
    for (var video in map["data"]) {
      topics.add(Topic.fromJson(video));
    }
    return topics;
  }
}
